package com.stmik.roninews

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CatalogRowActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.catalog_row)
    }
}